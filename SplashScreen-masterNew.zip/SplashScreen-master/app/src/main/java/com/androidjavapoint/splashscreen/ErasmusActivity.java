package com.androidjavapoint.splashscreen;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

/**
 * Created by skikos on 23/3/2018.
 */

public class ErasmusActivity extends AppCompatActivity {
    private TextView textErasmus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

    }
}
