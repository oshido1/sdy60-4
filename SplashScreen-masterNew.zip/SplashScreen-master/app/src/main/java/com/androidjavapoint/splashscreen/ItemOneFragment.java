/*
 * Copyright (c) 2017. Truiton (http://www.truiton.com/).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Contributors:
 * Mohit Gupt (https://github.com/mohitgupt)
 *
 */

package com.androidjavapoint.splashscreen;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;

public class ItemOneFragment extends Fragment implements PopupMenu.OnMenuItemClickListener, AdapterView.OnItemSelectedListener {

    TextView  name;
    TextView  mitroo;
    TextView  tmima;
    TextView  epidosi;
    TextView metakinisi;
    TextView forea;
    //TextView onoma_forea;
    TextView xora_forea;
    TextView old_metakinisi;
    TextView onoma_forea;
    Button button;
    Spinner spinner;
    TextView labelSpinner1;


    public static ItemOneFragment newInstance() {
        ItemOneFragment fragment = new ItemOneFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view  =inflater.inflate(R.layout.fragment_item_one, container, false);


         name = (TextView) view. findViewById(R.id.editText1);
         mitroo= (TextView) view. findViewById(R.id.editText2);
         tmima= (TextView) view. findViewById(R.id.editText3);
         epidosi = (TextView) view. findViewById(R.id.editText4);
         metakinisi= (TextView) view. findViewById(R.id.editText5);
         //forea= (TextView) view. findViewById(R.id.editText7);
         onoma_forea= (TextView) view. findViewById(R.id.editText7);
         xora_forea= (TextView) view. findViewById(R.id.editText8);
         old_metakinisi= (TextView) view. findViewById(R.id.editText9);
         button = (Button)view.findViewById(R.id.button);
         spinner = (Spinner)view.findViewById(R.id.editText6);
        labelSpinner1 = (TextView) view. findViewById(R.id.labelSpinner1);
         spinner.setOnItemSelectedListener(this);

         ArrayAdapter adapter = ArrayAdapter.createFromResource(getActivity(),R.array.spinner1, R.layout.spinner_item);
         spinner.setAdapter(adapter);

        view.findViewById(R.id.btn_erasmus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(getActivity(), view);
                popupMenu.setOnMenuItemClickListener(ItemOneFragment.this);
                popupMenu.inflate(R.menu.popup_menu);
                popupMenu.show();
            }
        });


        layout(0);

        return view;
    }

    public void layout(int k){
        Log.d("Shown","Hide "+k);
        if (k==0){
            name.setVisibility(View.INVISIBLE);
            mitroo.setVisibility(View.INVISIBLE);
            epidosi.setVisibility(View.INVISIBLE);
            metakinisi.setVisibility(View.INVISIBLE);
            tmima.setVisibility(View.INVISIBLE);
            spinner.setVisibility(View.INVISIBLE);
            xora_forea.setVisibility(View.INVISIBLE);
            onoma_forea.setVisibility(View.INVISIBLE);
            old_metakinisi.setVisibility(View.INVISIBLE);
            button.setVisibility(View.INVISIBLE);
            labelSpinner1.setVisibility(View.INVISIBLE);
        }
        if (k==1){
            Log.d("Shown","Hide");
            name.setVisibility(View.VISIBLE);
            mitroo.setVisibility(View.VISIBLE);
            epidosi.setVisibility(View.VISIBLE);
            metakinisi.setVisibility(View.VISIBLE);
            tmima.setVisibility(View.VISIBLE);
            spinner.setVisibility(View.VISIBLE);
            xora_forea.setVisibility(View.VISIBLE);
            old_metakinisi.setVisibility(View.VISIBLE);
            onoma_forea.setVisibility(View.VISIBLE);
            button.setVisibility(View.VISIBLE);
            labelSpinner1.setVisibility(View.VISIBLE);
        }

    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.item_stoixeia:
                Log.d("eeeeeeeeee", "1 Clicked");
                layout(1);
                return true;
            case R.id.item_aitisi:
                Log.d("eeeeeeeeee", "2 Clicked");
                return true;
            case R.id.item_diagrafi:
                Log.d("eeeeeeeeee", "3 Clicked");
                return true;
        }
        return false;
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
         // On selecting a spinner item
        //String item = parent.getItemAtPosition(position).toString();
        TextView myTxt = (TextView) view;
        // Showing selected spinner item
        Toast.makeText(parent.getContext(), "Selected: " + myTxt.getText(), Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
